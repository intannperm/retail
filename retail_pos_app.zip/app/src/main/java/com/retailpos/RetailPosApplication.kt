package com.retailpos

import android.app.Application
import com.retailpos.data.AppDatabase
import com.retailpos.data.repository.ProductRepository
import com.retailpos.data.repository.TransactionRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class RetailPosApplication : Application() {
    // Application scope
    private val applicationScope = CoroutineScope(SupervisorJob())

    // Database instance
    val database by lazy { AppDatabase.getDatabase(this, applicationScope) }
    
    // Repositories
    val productRepository by lazy { ProductRepository(database.productDao()) }
    val transactionRepository by lazy { 
        TransactionRepository(
            database.transactionDao(),
            database.transactionItemDao(),
            database.productDao()
        ) 
    }
}
