package com.retailpos.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.view.View
import com.retailpos.data.entity.Transaction
import com.retailpos.data.entity.TransactionItem
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Utility class for generating PDF documents
 */
object PdfGenerator {
    
    /**
     * Generate a receipt PDF for a transaction
     * @param context Application context
     * @param transaction The transaction to create a receipt for
     * @param items List of transaction items
     * @return The generated PDF file or null if there was an error
     */
    fun generateReceiptPdf(
        context: Context,
        transaction: Transaction,
        items: List<TransactionItem>
    ): File? {
        val pdfDocument = PdfDocument()
        
        // Create a page description
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        
        // Start the page
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()
        
        // Set text properties
        paint.color = Color.BLACK
        
        // Header
        paint.textSize = 25f
        paint.isFakeBoldText = true
        canvas.drawText("Retail POS System", 50f, 50f, paint)
        
        // Receipt details
        paint.textSize = 14f
        paint.isFakeBoldText = false
        canvas.drawText("Receipt #: " + transaction.id, 50f, 100f, paint)
        canvas.drawText("Date: " + DateTimeUtils.formatDate(transaction.date), 50f, 120f, paint)
        canvas.drawText("Time: " + DateTimeUtils.formatTime(transaction.date), 50f, 140f, paint)
        canvas.drawText("Cashier: " + transaction.cashierName, 50f, 160f, paint)
        
        // Line
        paint.strokeWidth = 1f
        canvas.drawLine(50f, 180f, 545f, 180f, paint)
        
        // Items header
        paint.isFakeBoldText = true
        canvas.drawText("Item", 50f, 200f, paint)
        canvas.drawText("Qty", 300f, 200f, paint)
        canvas.drawText("Price", 350f, 200f, paint)
        canvas.drawText("Subtotal", 450f, 200f, paint)
        
        // Line
        paint.isFakeBoldText = false
        canvas.drawLine(50f, 210f, 545f, 210f, paint)
        
        // Items
        var yPosition = 230f
        items.forEach { item ->
            canvas.drawText(item.productName, 50f, yPosition, paint)
            canvas.drawText(item.quantity.toString(), 300f, yPosition, paint)
            canvas.drawText(CurrencyFormatter.formatToRupiah(item.unitPrice), 350f, yPosition, paint)
            canvas.drawText(CurrencyFormatter.formatToRupiah(item.subtotal), 450f, yPosition, paint)
            yPosition += 20f
        }
        
        // Line
        canvas.drawLine(50f, yPosition, 545f, yPosition, paint)
        yPosition += 20f
        
        // Total
        paint.isFakeBoldText = true
        canvas.drawText("Total:", 350f, yPosition, paint)
        canvas.drawText(CurrencyFormatter.formatToRupiah(transaction.totalAmount), 450f, yPosition, paint)
        
        // Footer
        yPosition += 40f
        paint.isFakeBoldText = false
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("Thank you for your purchase!", pageInfo.pageWidth / 2f, yPosition, paint)
        
        // End the page
        pdfDocument.finishPage(page)
        
        // Create output directory if it doesn't exist
        val outputDir = File(context.getExternalFilesDir(null), "receipts")
        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }
        
        // Create output file
        val fileName = "receipt_${transaction.id}_${System.currentTimeMillis()}.pdf"
        val outputFile = File(outputDir, fileName)
        
        // Write to file
        try {
            pdfDocument.writeTo(FileOutputStream(outputFile))
            return outputFile
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        } finally {
            pdfDocument.close()
        }
    }
    
    /**
     * Generate a sales report PDF
     * @param context Application context
     * @param transactions List of transactions in the report
     * @param startDate Start date of the report period
     * @param endDate End date of the report period
     * @param totalSales Total sales amount
     * @return The generated PDF file or null if there was an error
     */
    fun generateSalesReportPdf(
        context: Context,
        transactions: List<Transaction>,
        startDate: String,
        endDate: String,
        totalSales: Double
    ): File? {
        val pdfDocument = PdfDocument()
        
        // Create a page description
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        
        // Start the page
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()
        
        // Set text properties
        paint.color = Color.BLACK
        
        // Header
        paint.textSize = 25f
        paint.isFakeBoldText = true
        canvas.drawText("Sales Report", 50f, 50f, paint)
        
        // Report details
        paint.textSize = 14f
        paint.isFakeBoldText = false
        canvas.drawText("Period: $startDate to $endDate", 50f, 100f, paint)
        canvas.drawText("Total Transactions: ${transactions.size}", 50f, 120f, paint)
        canvas.drawText("Total Sales: ${CurrencyFormatter.formatToRupiah(totalSales)}", 50f, 140f, paint)
        
        // Line
        paint.strokeWidth = 1f
        canvas.drawLine(50f, 160f, 545f, 160f, paint)
        
        // Transactions header
        paint.isFakeBoldText = true
        canvas.drawText("Transaction ID", 50f, 180f, paint)
        canvas.drawText("Date", 150f, 180f, paint)
        canvas.drawText("Time", 250f, 180f, paint)
        canvas.drawText("Items", 320f, 180f, paint)
        canvas.drawText("Amount", 450f, 180f, paint)
        
        // Line
        paint.isFakeBoldText = false
        canvas.drawLine(50f, 190f, 545f, 190f, paint)
        
        // Transactions
        var yPosition = 210f
        transactions.forEach { transaction ->
            canvas.drawText(transaction.id.toString(), 50f, yPosition, paint)
            canvas.drawText(DateTimeUtils.formatDate(transaction.date), 150f, yPosition, paint)
            canvas.drawText(DateTimeUtils.formatTime(transaction.date), 250f, yPosition, paint)
            canvas.drawText(transaction.itemCount.toString(), 320f, yPosition, paint)
            canvas.drawText(CurrencyFormatter.formatToRupiah(transaction.totalAmount), 450f, yPosition, paint)
            yPosition += 20f
            
            // Add page if needed
            if (yPosition > 800f && transactions.indexOf(transaction) < transactions.size - 1) {
                pdfDocument.finishPage(page)
                val newPageInfo = PdfDocument.PageInfo.Builder(595, 842, pdfDocument.pages.size + 1).create()
                val newPage = pdfDocument.startPage(newPageInfo)
                canvas = newPage.canvas
                
                // Header for new page
                paint.textSize = 25f
                paint.isFakeBoldText = true
                canvas.drawText("Sales Report (continued)", 50f, 50f, paint)
                
                // Transactions header
                paint.textSize = 14f
                paint.isFakeBoldText = true
                canvas.drawText("Transaction ID", 50f, 80f, paint)
                canvas.drawText("Date", 150f, 80f, paint)
                canvas.drawText("Time", 250f, 80f, paint)
                canvas.drawText("Items", 320f, 80f, paint)
                canvas.drawText("Amount", 450f, 80f, paint)
                
                // Line
                paint.isFakeBoldText = false
                canvas.drawLine(50f, 90f, 545f, 90f, paint)
                
                yPosition = 110f
            }
        }
        
        // Line
        canvas.drawLine(50f, yPosition, 545f, yPosition, paint)
        yPosition += 20f
        
        // Summary
        paint.isFakeBoldText = true
        canvas.drawText("Total:", 350f, yPosition, paint)
        canvas.drawText(CurrencyFormatter.formatToRupiah(totalSales), 450f, yPosition, paint)
        
        // End the page
        pdfDocument.finishPage(page)
        
        // Create output directory if it doesn't exist
        val outputDir = File(context.getExternalFilesDir(null), "reports")
        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }
        
        // Create output file
        val fileName = "sales_report_${System.currentTimeMillis()}.pdf"
        val outputFile = File(outputDir, fileName)
        
        // Write to file
        try {
            pdfDocument.writeTo(FileOutputStream(outputFile))
            return outputFile
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        } finally {
            pdfDocument.close()
        }
    }
    
    /**
     * Capture a view into a PDF document
     * @param context Application context
     * @param fileName Name of the PDF file to create
     * @param view The view to capture
     * @return The generated PDF file or null if there was an error
     */
    fun generatePdfFromView(context: Context, fileName: String, view: View): File? {
        // Measure view to get dimensions
        val width = view.width
        val height = view.height
        
        // Create bitmap
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        
        // Create PDF document
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(width, height, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        
        // Draw bitmap on PDF canvas
        page.canvas.drawBitmap(bitmap, 0f, 0f, null)
        
        // End the page
        pdfDocument.finishPage(page)
        
        // Create output directory if it doesn't exist
        val outputDir = File(context.getExternalFilesDir(null), "pdfs")
        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }
        
        // Create output file
        val outputFile = File(outputDir, fileName)
        
        // Write to file
        try {
            pdfDocument.writeTo(FileOutputStream(outputFile))
            return outputFile
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        } finally {
            pdfDocument.close()
            bitmap.recycle()
        }
    }
}
