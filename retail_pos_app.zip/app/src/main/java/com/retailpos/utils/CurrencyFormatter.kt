package com.retailpos.utils

import java.text.NumberFormat
import java.util.*

/**
 * Utility class for formatting currency values
 */
object CurrencyFormatter {
    private val indonesianFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    
    init {
        indonesianFormat.maximumFractionDigits = 0
    }
    
    /**
     * Format a double value as Indonesian Rupiah
     */
    fun formatToRupiah(amount: Double): String {
        return indonesianFormat.format(amount)
    }
    
    /**
     * Format a double value as Indonesian Rupiah without currency symbol
     */
    fun formatToNumber(amount: Double): String {
        return amount.toInt().toString()
    }
    
    /**
     * Parse a Rupiah string to double
     */
    fun parseRupiah(rupiahString: String): Double {
        return try {
            val cleanString = rupiahString
                .replace("Rp", "")
                .replace(".", "")
                .replace(",", ".")
                .trim()
            cleanString.toDouble()
        } catch (e: Exception) {
            0.0
        }
    }
}
