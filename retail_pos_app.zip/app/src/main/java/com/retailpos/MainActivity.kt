package com.retailpos

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.retailpos.ui.cart.CartActivity
import com.retailpos.ui.history.TransactionHistoryActivity
import com.retailpos.ui.inventory.InventoryActivity
import com.retailpos.ui.reports.SalesReportActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        // Checkout menu
        findViewById<CardView>(R.id.cardCheckout).setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }

        // Inventory menu
        findViewById<CardView>(R.id.cardInventory).setOnClickListener {
            startActivity(Intent(this, InventoryActivity::class.java))
        }

        // Transaction History menu
        findViewById<CardView>(R.id.cardHistory).setOnClickListener {
            startActivity(Intent(this, TransactionHistoryActivity::class.java))
        }

        // Sales Report menu
        findViewById<CardView>(R.id.cardReports).setOnClickListener {
            startActivity(Intent(this, SalesReportActivity::class.java))
        }
    }
}
