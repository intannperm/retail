package com.retailpos.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.retailpos.data.dao.ProductDao
import com.retailpos.data.dao.TransactionDao
import com.retailpos.data.dao.TransactionItemDao
import com.retailpos.data.entity.Product
import com.retailpos.data.entity.Transaction
import com.retailpos.data.entity.TransactionItem
import com.retailpos.data.util.DateConverter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(
    entities = [Product::class, Transaction::class, TransactionItem::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(DateConverter::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun productDao(): ProductDao
    abstract fun transactionDao(): TransactionDao
    abstract fun transactionItemDao(): TransactionItemDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "retail_pos_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(AppDatabaseCallback(scope))
                .build()
                
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch {
                    populateDatabase(database.productDao())
                }
            }
        }

        suspend fun populateDatabase(productDao: ProductDao) {
            // Delete all content here
            productDao.deleteAll()

            // Add sample products
            val product1 = Product(
                code = "P001",
                name = "Instant Noodles",
                price = 3500.0,
                stock = 100
            )
            val product2 = Product(
                code = "P002",
                name = "Mineral Water 600ml",
                price = 3000.0,
                stock = 200
            )
            val product3 = Product(
                code = "P003",
                name = "White Bread",
                price = 10000.0,
                stock = 50
            )
            val product4 = Product(
                code = "P004",
                name = "Chocolate Bar",
                price = 7500.0,
                stock = 80
            )
            val product5 = Product(
                code = "P005",
                name = "Fresh Milk 1L",
                price = 15000.0,
                stock = 30
            )
            
            productDao.insert(product1)
            productDao.insert(product2)
            productDao.insert(product3)
            productDao.insert(product4)
            productDao.insert(product5)
        }
    }
}
