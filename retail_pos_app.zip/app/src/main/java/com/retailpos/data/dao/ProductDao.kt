package com.retailpos.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.retailpos.data.entity.Product
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>
    
    @Query("SELECT * FROM products WHERE id = :id")
    fun getProductById(id: Long): Flow<Product>
    
    @Query("SELECT * FROM products WHERE code = :code")
    fun getProductByCode(code: String): Flow<Product?>
    
    @Query("SELECT * FROM products WHERE name LIKE '%' || :searchQuery || '%' OR code LIKE '%' || :searchQuery || '%'")
    fun searchProducts(searchQuery: String): Flow<List<Product>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(product: Product): Long
    
    @Update
    suspend fun update(product: Product)
    
    @Delete
    suspend fun delete(product: Product)
    
    @Query("DELETE FROM products")
    suspend fun deleteAll()
    
    @Query("UPDATE products SET stock = stock - :quantity WHERE id = :productId AND stock >= :quantity")
    suspend fun decreaseStock(productId: Long, quantity: Int): Int
    
    @Query("UPDATE products SET stock = stock + :quantity WHERE id = :productId")
    suspend fun increaseStock(productId: Long, quantity: Int)
    
    @Query("SELECT * FROM products WHERE stock <= 5 ORDER BY stock ASC")
    fun getLowStockProducts(): Flow<List<Product>>
}
