package com.retailpos.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: Date = Date(),
    val totalAmount: Double,
    val itemCount: Int,
    val paymentMethod: String = "Cash",
    val cashierName: String = "Cashier"
)
