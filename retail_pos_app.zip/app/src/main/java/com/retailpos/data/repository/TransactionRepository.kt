package com.retailpos.data.repository

import androidx.annotation.WorkerThread
import com.retailpos.data.dao.ProductDao
import com.retailpos.data.dao.TransactionDao
import com.retailpos.data.dao.TransactionItemDao
import com.retailpos.data.entity.Transaction
import com.retailpos.data.entity.TransactionItem
import kotlinx.coroutines.flow.Flow
import java.util.Calendar
import java.util.Date

class TransactionRepository(
    private val transactionDao: TransactionDao,
    private val transactionItemDao: TransactionItemDao,
    private val productDao: ProductDao
) {

    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()

    fun getTransactionById(id: Long): Flow<Transaction> {
        return transactionDao.getTransactionById(id)
    }

    fun getTransactionItems(transactionId: Long): Flow<List<TransactionItem>> {
        return transactionItemDao.getItemsByTransactionId(transactionId)
    }

    fun getTransactionsByDateRange(startDate: Date, endDate: Date): Flow<List<Transaction>> {
        return transactionDao.getTransactionsByDateRange(startDate, endDate)
    }

    fun getTotalSalesByDateRange(startDate: Date, endDate: Date): Flow<Double?> {
        return transactionDao.getTotalSalesByDateRange(startDate, endDate)
    }

    fun getTransactionCountByDateRange(startDate: Date, endDate: Date): Flow<Int> {
        return transactionDao.getTransactionCountByDateRange(startDate, endDate)
    }

    fun getDailySalesReport(): Flow<List<Transaction>> {
        // Get today's date range
        val calendar = Calendar.getInstance()
        
        // Set time to start of day
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startDate = calendar.time
        
        // Set time to end of day
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        val endDate = calendar.time
        
        return transactionDao.getTransactionsByDateRange(startDate, endDate)
    }

    @WorkerThread
    suspend fun saveTransaction(
        transaction: Transaction,
        items: List<TransactionItem>
    ): Long {
        // 1. Insert transaction
        val transactionId = transactionDao.insert(transaction)
        
        // 2. Update items with transaction ID and insert them
        val updatedItems = items.map { item ->
            item.copy(transactionId = transactionId)
        }
        transactionItemDao.insertAll(updatedItems)
        
        // 3. Decrease product stock for each item
        items.forEach { item ->
            productDao.decreaseStock(item.productId, item.quantity)
        }
        
        return transactionId
    }

    @WorkerThread
    suspend fun deleteTransaction(transaction: Transaction) {
        // This will also delete associated items due to CASCADE relationship
        transactionDao.delete(transaction)
    }
}
