package com.retailpos.data.dao

import androidx.room.*
import com.retailpos.data.entity.TransactionItem
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionItemDao {
    @Query("SELECT * FROM transaction_items WHERE transactionId = :transactionId")
    fun getItemsByTransactionId(transactionId: Long): Flow<List<TransactionItem>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transactionItem: TransactionItem): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactionItems: List<TransactionItem>)
    
    @Update
    suspend fun update(transactionItem: TransactionItem)
    
    @Delete
    suspend fun delete(transactionItem: TransactionItem)
    
    @Query("DELETE FROM transaction_items WHERE transactionId = :transactionId")
    suspend fun deleteByTransactionId(transactionId: Long)
    
    @Query("SELECT * FROM transaction_items WHERE productId = :productId")
    fun getItemsByProductId(productId: Long): Flow<List<TransactionItem>>
    
    @Query("SELECT SUM(quantity) FROM transaction_items WHERE productId = :productId")
    fun getTotalSoldByProductId(productId: Long): Flow<Int?>
}
