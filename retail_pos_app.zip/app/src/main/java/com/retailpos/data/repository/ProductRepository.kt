package com.retailpos.data.repository

import androidx.annotation.WorkerThread
import com.retailpos.data.dao.ProductDao
import com.retailpos.data.entity.Product
import kotlinx.coroutines.flow.Flow

class ProductRepository(private val productDao: ProductDao) {

    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val lowStockProducts: Flow<List<Product>> = productDao.getLowStockProducts()

    fun getProductById(id: Long): Flow<Product> {
        return productDao.getProductById(id)
    }

    fun getProductByCode(code: String): Flow<Product?> {
        return productDao.getProductByCode(code)
    }

    fun searchProducts(query: String): Flow<List<Product>> {
        return productDao.searchProducts(query)
    }

    @WorkerThread
    suspend fun insert(product: Product): Long {
        return productDao.insert(product)
    }

    @WorkerThread
    suspend fun update(product: Product) {
        productDao.update(product)
    }

    @WorkerThread
    suspend fun delete(product: Product) {
        productDao.delete(product)
    }

    @WorkerThread
    suspend fun decreaseStock(productId: Long, quantity: Int): Boolean {
        // Returns affected rows count (should be 1 if successful)
        val result = productDao.decreaseStock(productId, quantity)
        return result > 0
    }

    @WorkerThread
    suspend fun increaseStock(productId: Long, quantity: Int) {
        productDao.increaseStock(productId, quantity)
    }
}
