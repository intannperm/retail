package com.retailpos.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "products",
    indices = [Index(value = ["code"], unique = true)]
)
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val code: String,
    val name: String,
    val price: Double,
    val stock: Int,
    val description: String = "",
    val category: String = ""
) {
    fun isLowStock(): Boolean = stock <= 5
}
