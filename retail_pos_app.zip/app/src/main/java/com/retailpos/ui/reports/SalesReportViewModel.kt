package com.retailpos.ui.reports

import androidx.lifecycle.*
import com.retailpos.data.entity.Transaction
import com.retailpos.data.repository.TransactionRepository
import com.retailpos.utils.DateTimeUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*

class SalesReportViewModel(private val repository: TransactionRepository) : ViewModel() {

    // Date range for report
    private val _startDate = MutableStateFlow(DateTimeUtils.getStartOfToday())
    val startDate: StateFlow<Date> = _startDate.asStateFlow()

    private val _endDate = MutableStateFlow(DateTimeUtils.getEndOfToday())
    val endDate: StateFlow<Date> = _endDate.asStateFlow()

    // Transactions for report
    private val _transactions = MutableLiveData<List<Transaction>>()
    val transactions: LiveData<List<Transaction>> = _transactions

    // Daily sales summary
    private val _dailySalesSummary = MutableLiveData<List<DailySalesSummary>>()
    val dailySalesSummary: LiveData<List<DailySalesSummary>> = _dailySalesSummary

    // Total sales in date range
    private val _totalSales = MutableStateFlow(0.0)
    val totalSales: StateFlow<Double> = _totalSales.asStateFlow()

    // Total transaction count in date range
    private val _totalTransactions = MutableStateFlow(0)
    val totalTransactions: StateFlow<Int> = _totalTransactions.asStateFlow()

    // Loading state
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        generateReport()
    }

    /**
     * Set start date for report
     */
    fun setStartDate(date: Date) {
        _startDate.value = DateTimeUtils.getStartOfDay(date)
    }

    /**
     * Set end date for report
     */
    fun setEndDate(date: Date) {
        _endDate.value = DateTimeUtils.getEndOfDay(date)
    }

    /**
     * Generate report for current date range
     */
    fun generateReport() {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                // Load transactions
                repository.getTransactionsByDateRange(_startDate.value, _endDate.value)
                    .collectLatest { transactions ->
                        _transactions.value = transactions
                        generateDailySummary(transactions)
                    }

                // Get total sales
                repository.getTotalSalesByDateRange(_startDate.value, _endDate.value)
                    .collectLatest { total ->
                        _totalSales.value = total ?: 0.0
                    }

                // Get transaction count
                repository.getTransactionCountByDateRange(_startDate.value, _endDate.value)
                    .collectLatest { count ->
                        _totalTransactions.value = count
                    }
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Generate daily sales summary from transactions
     */
    private fun generateDailySummary(transactions: List<Transaction>) {
        if (transactions.isEmpty()) {
            _dailySalesSummary.value = emptyList()
            return
        }

        val dailySummaryMap = mutableMapOf<String, DailySalesSummary>()

        // Group transactions by date
        transactions.forEach { transaction ->
            val dateStr = DateTimeUtils.formatDate(transaction.date)
            val summary = dailySummaryMap.getOrPut(dateStr) {
                DailySalesSummary(transaction.date, 0, 0.0)
            }
            dailySummaryMap[dateStr] = summary.copy(
                transactionCount = summary.transactionCount + 1,
                totalSales = summary.totalSales + transaction.totalAmount
            )
        }

        // Convert map to sorted list (newest first)
        _dailySalesSummary.value = dailySummaryMap.values.sortedByDescending { it.date }
    }

    /**
     * Data class for daily sales summary
     */
    data class DailySalesSummary(
        val date: Date,
        val transactionCount: Int,
        val totalSales: Double
    )
}

/**
 * Factory for creating SalesReportViewModel with dependencies
 */
class SalesReportViewModelFactory(private val repository: TransactionRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SalesReportViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SalesReportViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
