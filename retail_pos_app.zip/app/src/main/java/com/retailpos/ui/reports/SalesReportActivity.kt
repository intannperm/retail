package com.retailpos.ui.reports

import android.app.DatePickerDialog
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.retailpos.R
import com.retailpos.RetailPosApplication
import com.retailpos.databinding.ActivitySalesReportBinding
import com.retailpos.utils.CurrencyFormatter
import com.retailpos.utils.DateTimeUtils
import com.retailpos.utils.PdfGenerator
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File
import java.util.*

class SalesReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySalesReportBinding
    private lateinit var adapter: SalesReportAdapter

    private val viewModel: SalesReportViewModel by viewModels {
        SalesReportViewModelFactory((application as RetailPosApplication).transactionRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalesReportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.report_title)

        setupRecyclerView()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = SalesReportAdapter()
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@SalesReportActivity)
            adapter = this@SalesReportActivity.adapter
        }
    }

    private fun setupClickListeners() {
        // Start date selector
        binding.btnStartDate.setOnClickListener {
            showDatePicker(true)
        }

        // End date selector
        binding.btnEndDate.setOnClickListener {
            showDatePicker(false)
        }

        // Generate report button
        binding.btnGenerateReport.setOnClickListener {
            viewModel.generateReport()
        }

        // Export report button
        binding.btnExportReport.setOnClickListener {
            exportReportToPdf()
        }
    }

    private fun observeViewModel() {
        // Observe date range
        lifecycleScope.launch {
            viewModel.startDate.collectLatest { startDate ->
                binding.btnStartDate.text = DateTimeUtils.formatDate(startDate)
            }
        }

        lifecycleScope.launch {
            viewModel.endDate.collectLatest { endDate ->
                binding.btnEndDate.text = DateTimeUtils.formatDate(endDate)
            }
        }

        // Observe daily sales summary
        viewModel.dailySalesSummary.observe(this) { summaryList ->
            adapter.submitList(summaryList)
            updateEmptyStateVisibility(summaryList.isEmpty())
        }

        // Observe totals
        lifecycleScope.launch {
            viewModel.totalSales.collectLatest { totalSales ->
                binding.tvTotalSales.text = getString(
                    R.string.report_total_sales,
                    CurrencyFormatter.formatToRupiah(totalSales)
                )
            }
        }

        lifecycleScope.launch {
            viewModel.totalTransactions.collectLatest { count ->
                binding.tvTotalTransactions.text = getString(
                    R.string.report_total_transactions,
                    count
                )
            }
        }

        // Observe loading state
        lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }
    }

    private fun updateEmptyStateVisibility(isEmpty: Boolean) {
        binding.tvEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE
        binding.btnExportReport.isEnabled = !isEmpty
    }

    private fun showDatePicker(isStartDate: Boolean) {
        val calendar = Calendar.getInstance()
        if (isStartDate) {
            calendar.time = viewModel.startDate.value
        } else {
            calendar.time = viewModel.endDate.value
        }

        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                calendar.set(year, month, dayOfMonth)
                if (isStartDate) {
                    // Ensure start date is not after end date
                    if (calendar.time.after(viewModel.endDate.value)) {
                        Toast.makeText(this, "Start date cannot be after end date", Toast.LENGTH_SHORT).show()
                        return@DatePickerDialog
                    }
                    viewModel.setStartDate(calendar.time)
                } else {
                    // Ensure end date is not before start date
                    if (calendar.time.before(viewModel.startDate.value)) {
                        Toast.makeText(this, "End date cannot be before start date", Toast.LENGTH_SHORT).show()
                        return@DatePickerDialog
                    }
                    viewModel.setEndDate(calendar.time)
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun exportReportToPdf() {
        if (viewModel.transactions.value.isNullOrEmpty()) {
            Toast.makeText(this, "No data to export", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE

        // Generate PDF in background
        Thread {
            val pdfFile = PdfGenerator.generateSalesReportPdf(
                this,
                viewModel.transactions.value!!,
                DateTimeUtils.formatDate(viewModel.startDate.value),
                DateTimeUtils.formatDate(viewModel.endDate.value),
                viewModel.totalSales.value
            )

            runOnUiThread {
                binding.progressBar.visibility = View.GONE

                if (pdfFile != null) {
                    Toast.makeText(this, getString(R.string.report_saved), Toast.LENGTH_SHORT).show()
                    openPdfFile(pdfFile)
                } else {
                    Toast.makeText(this, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun openPdfFile(file: File) {
        val uri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.provider",
            file
        )

        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "No application available to view PDF", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
