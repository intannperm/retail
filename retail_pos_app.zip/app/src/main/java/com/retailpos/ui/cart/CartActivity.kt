package com.retailpos.ui.cart

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.retailpos.R
import com.retailpos.RetailPosApplication
import com.retailpos.data.entity.Product
import com.retailpos.databinding.ActivityCartBinding
import com.retailpos.ui.receipt.ReceiptActivity
import com.retailpos.utils.CurrencyFormatter
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class CartActivity : AppCompatActivity(), CartAdapter.CartItemListener {

    private lateinit var binding: ActivityCartBinding
    private lateinit var cartAdapter: CartAdapter
    private lateinit var searchAdapter: ProductSearchAdapter

    private val viewModel: CartViewModel by viewModels {
        CartViewModelFactory(
            (application as RetailPosApplication).productRepository,
            (application as RetailPosApplication).transactionRepository
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.cart_title)

        setupRecyclerViews()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupRecyclerViews() {
        // Cart RecyclerView
        cartAdapter = CartAdapter(this)
        binding.rvCartItems.apply {
            layoutManager = LinearLayoutManager(this@CartActivity)
            adapter = cartAdapter
            addItemDecoration(DividerItemDecoration(this@CartActivity, DividerItemDecoration.VERTICAL))
        }

        // Search results RecyclerView
        searchAdapter = ProductSearchAdapter(this::onProductSelected)
        binding.rvSearchResults.apply {
            layoutManager = LinearLayoutManager(this@CartActivity)
            adapter = searchAdapter
            addItemDecoration(DividerItemDecoration(this@CartActivity, DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupClickListeners() {
        // Search
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.setSearchQuery(newText ?: "")
                return true
            }
        })

        // Complete sale button
        binding.btnCheckout.setOnClickListener {
            if (viewModel.cartItems.value.isEmpty()) {
                Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            AlertDialog.Builder(this)
                .setTitle("Complete Sale")
                .setMessage("Do you want to complete this sale?")
                .setPositiveButton("Yes") { _, _ ->
                    viewModel.completeTransaction()
                }
                .setNegativeButton("No", null)
                .show()
        }

        // Clear cart button
        binding.btnClearCart.setOnClickListener {
            if (viewModel.cartItems.value.isEmpty()) {
                return@setOnClickListener
            }
            
            AlertDialog.Builder(this)
                .setTitle("Clear Cart")
                .setMessage("Do you want to clear all items from the cart?")
                .setPositiveButton("Yes") { _, _ ->
                    viewModel.clearCart()
                }
                .setNegativeButton("No", null)
                .show()
        }
    }

    private fun observeViewModel() {
        // Observe search results
        viewModel.searchResults.observe(this) { products ->
            searchAdapter.submitList(products)
            binding.rvSearchResults.visibility = if (products.isNotEmpty()) View.VISIBLE else View.GONE
            binding.tvNoSearchResults.visibility = if (products.isEmpty() && viewModel.searchQuery.value.isNotEmpty()) View.VISIBLE else View.GONE
        }

        // Observe cart items
        lifecycleScope.launch {
            viewModel.cartItems.collectLatest { items ->
                cartAdapter.submitList(items)
                binding.tvEmptyCart.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                binding.cartSummaryLayout.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
            }
        }

        // Observe total amount
        lifecycleScope.launch {
            viewModel.totalAmount.collectLatest { total ->
                binding.tvTotalAmount.text = CurrencyFormatter.formatToRupiah(total)
            }
        }

        // Observe loading state
        lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }

        // Observe error message
        lifecycleScope.launch {
            viewModel.errorMessage.collectLatest { errorMessage ->
                if (errorMessage != null) {
                    Toast.makeText(this@CartActivity, errorMessage, Toast.LENGTH_SHORT).show()
                    viewModel.resetErrorMessage()
                }
            }
        }

        // Observe last transaction ID
        lifecycleScope.launch {
            viewModel.lastTransactionId.collectLatest { transactionId ->
                if (transactionId != null) {
                    // Navigate to receipt screen
                    val intent = Intent(this@CartActivity, ReceiptActivity::class.java).apply {
                        putExtra(ReceiptActivity.EXTRA_TRANSACTION_ID, transactionId)
                    }
                    startActivity(intent)
                    viewModel.resetLastTransactionId()
                }
            }
        }
    }

    private fun onProductSelected(product: Product) {
        showQuantityDialog(product)
    }

    private fun showQuantityDialog(product: Product) {
        val quantityDialog = QuantityDialogFragment.newInstance(product)
        quantityDialog.setQuantityDialogListener(object : QuantityDialogFragment.QuantityDialogListener {
            override fun onQuantityConfirmed(product: Product, quantity: Int) {
                viewModel.addToCart(product, quantity)
                binding.searchView.setQuery("", false)
                binding.searchView.clearFocus()
            }
        })
        quantityDialog.show(supportFragmentManager, "QuantityDialog")
    }

    override fun onCartItemQuantityChanged(item: CartViewModel.CartItem, quantity: Int) {
        viewModel.updateCartItemQuantity(item, quantity)
    }

    override fun onCartItemRemoved(item: CartViewModel.CartItem) {
        viewModel.removeFromCart(item)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_cart, menu)
        return true
    }
}
