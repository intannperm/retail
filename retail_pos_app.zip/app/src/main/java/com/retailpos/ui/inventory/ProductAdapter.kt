package com.retailpos.ui.inventory

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.retailpos.data.entity.Product
import com.retailpos.databinding.ItemProductInventoryBinding
import com.retailpos.utils.CurrencyFormatter

class ProductAdapter(private val listener: ProductClickListener) : 
    ListAdapter<Product, ProductAdapter.ProductViewHolder>(ProductDiffCallback()) {

    interface ProductClickListener {
        fun onProductClick(product: Product)
        fun onDeleteClick(product: Product)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ItemProductInventoryBinding.inflate(
            LayoutInflater.from(parent.context), 
            parent, 
            false
        )
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ProductViewHolder(private val binding: ItemProductInventoryBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        init {
            binding.root.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener.onProductClick(getItem(position))
                }
            }
            
            binding.btnDelete.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener.onDeleteClick(getItem(position))
                }
            }
        }
        
        fun bind(product: Product) {
            binding.tvProductName.text = product.name
            binding.tvProductCode.text = product.code
            binding.tvPrice.text = CurrencyFormatter.formatToRupiah(product.price)
            binding.tvStock.text = "Stock: ${product.stock}"
            
            // Highlight low stock
            if (product.isLowStock()) {
                binding.tvStock.setTextColor(binding.root.context.getColor(com.retailpos.R.color.error_red))
            } else {
                binding.tvStock.setTextColor(binding.root.context.getColor(com.retailpos.R.color.text_secondary))
            }
            
            if (product.category.isNotEmpty()) {
                binding.tvCategory.text = "Category: ${product.category}"
                binding.tvCategory.visibility = ViewGroup.VISIBLE
            } else {
                binding.tvCategory.visibility = ViewGroup.GONE
            }
        }
    }

    private class ProductDiffCallback : DiffUtil.ItemCallback<Product>() {
        override fun areItemsTheSame(oldItem: Product, newItem: Product): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Product, newItem: Product): Boolean {
            return oldItem == newItem
        }
    }
}
