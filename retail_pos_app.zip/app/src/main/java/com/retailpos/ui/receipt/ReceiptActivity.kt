package com.retailpos.ui.receipt

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.retailpos.R
import com.retailpos.RetailPosApplication
import com.retailpos.data.entity.Transaction
import com.retailpos.data.entity.TransactionItem
import com.retailpos.databinding.ActivityReceiptBinding
import com.retailpos.ui.history.TransactionHistoryViewModel
import com.retailpos.ui.history.TransactionHistoryViewModelFactory
import com.retailpos.utils.CurrencyFormatter
import com.retailpos.utils.DateTimeUtils
import com.retailpos.utils.PdfGenerator
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class ReceiptActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TRANSACTION_ID = "extra_transaction_id"
    }

    private lateinit var binding: ActivityReceiptBinding
    private val viewModel: TransactionHistoryViewModel by viewModels {
        TransactionHistoryViewModelFactory((application as RetailPosApplication).transactionRepository)
    }

    private var transactionId: Long = 0
    private var currentTransaction: Transaction? = null
    private var transactionItems: List<TransactionItem> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReceiptBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.receipt_title)

        transactionId = intent.getLongExtra(EXTRA_TRANSACTION_ID, 0)
        if (transactionId <= 0) {
            Toast.makeText(this, "Invalid transaction ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setupClickListeners()
        loadTransactionData()
    }

    private fun setupClickListeners() {
        // Save PDF button
        binding.btnSavePdf.setOnClickListener {
            saveReceiptAsPdf()
        }

        // Done button
        binding.btnDone.setOnClickListener {
            finish()
        }
    }

    private fun loadTransactionData() {
        binding.progressBar.visibility = View.VISIBLE

        // Load transaction
        viewModel.getTransactionById(transactionId).observe(this) { transaction ->
            currentTransaction = transaction
            updateReceiptHeader(transaction)
        }

        // Load transaction items
        lifecycleScope.launch {
            (application as RetailPosApplication).transactionRepository
                .getTransactionItems(transactionId)
                .collectLatest { items ->
                    transactionItems = items
                    updateReceiptItems(items)
                    binding.progressBar.visibility = View.GONE
                }
        }
    }

    private fun updateReceiptHeader(transaction: Transaction) {
        binding.tvTransactionId.text = getString(R.string.receipt_transaction_id, transaction.id.toString())
        binding.tvDate.text = getString(R.string.receipt_date, DateTimeUtils.formatDate(transaction.date))
        binding.tvTime.text = getString(R.string.receipt_time, DateTimeUtils.formatTime(transaction.date))
        binding.tvCashier.text = "Cashier: ${transaction.cashierName}"
        binding.tvTotal.text = CurrencyFormatter.formatToRupiah(transaction.totalAmount)
    }

    private fun updateReceiptItems(items: List<TransactionItem>) {
        binding.itemsContainer.removeAllViews()

        items.forEach { item ->
            val itemView = layoutInflater.inflate(R.layout.item_receipt_row, binding.itemsContainer, false)
            
            val tvName = itemView.findViewById<TextView>(R.id.tvItemName)
            val tvQuantity = itemView.findViewById<TextView>(R.id.tvItemQuantity)
            val tvPrice = itemView.findViewById<TextView>(R.id.tvItemPrice)
            val tvSubtotal = itemView.findViewById<TextView>(R.id.tvItemSubtotal)
            
            tvName.text = "${item.productName} (${item.productCode})"
            tvQuantity.text = item.quantity.toString()
            tvPrice.text = CurrencyFormatter.formatToRupiah(item.unitPrice)
            tvSubtotal.text = CurrencyFormatter.formatToRupiah(item.subtotal)
            
            binding.itemsContainer.addView(itemView)
        }
    }

    private fun saveReceiptAsPdf() {
        if (currentTransaction == null) {
            Toast.makeText(this, "Transaction data not loaded yet", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE

        // Generate PDF in background
        Thread {
            val pdfFile = PdfGenerator.generateReceiptPdf(
                this,
                currentTransaction!!,
                transactionItems
            )

            runOnUiThread {
                binding.progressBar.visibility = View.GONE

                if (pdfFile != null) {
                    Toast.makeText(this, getString(R.string.receipt_saved), Toast.LENGTH_SHORT).show()
                    openPdfFile(pdfFile)
                } else {
                    Toast.makeText(this, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun openPdfFile(file: File) {
        val uri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.provider",
            file
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "No application available to view PDF", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
