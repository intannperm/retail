package com.retailpos.ui.cart

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.retailpos.data.entity.Product
import com.retailpos.databinding.DialogQuantityBinding

class QuantityDialogFragment : DialogFragment() {

    private var _binding: DialogQuantityBinding? = null
    private val binding get() = _binding!!
    
    private var product: Product? = null
    private var listener: QuantityDialogListener? = null

    interface QuantityDialogListener {
        fun onQuantityConfirmed(product: Product, quantity: Int)
    }

    companion object {
        private const val ARG_PRODUCT = "arg_product"

        fun newInstance(product: Product): QuantityDialogFragment {
            val fragment = QuantityDialogFragment()
            val args = Bundle().apply {
                putParcelable(ARG_PRODUCT, product)
            }
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        product = arguments?.getParcelable(ARG_PRODUCT)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogQuantityBinding.inflate(LayoutInflater.from(context))

        product?.let { product ->
            binding.tvProductName.text = product.name
            binding.tvProductCode.text = product.code
            binding.tvAvailableStock.text = "Available: ${product.stock}"
            binding.etQuantity.setText("1")

            // Quantity controls
            binding.btnDecrease.setOnClickListener {
                val currentQty = binding.etQuantity.text.toString().toIntOrNull() ?: 1
                if (currentQty > 1) {
                    binding.etQuantity.setText((currentQty - 1).toString())
                }
            }

            binding.btnIncrease.setOnClickListener {
                val currentQty = binding.etQuantity.text.toString().toIntOrNull() ?: 1
                if (currentQty < product.stock) {
                    binding.etQuantity.setText((currentQty + 1).toString())
                } else {
                    Toast.makeText(context, "Maximum stock reached", Toast.LENGTH_SHORT).show()
                }
            }
        }

        return AlertDialog.Builder(requireContext())
            .setTitle("Add to Cart")
            .setView(binding.root)
            .setPositiveButton("Add") { _, _ ->
                product?.let { product ->
                    val quantity = binding.etQuantity.text.toString().toIntOrNull() ?: 1
                    if (quantity > 0 && quantity <= product.stock) {
                        listener?.onQuantityConfirmed(product, quantity)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .create()
    }

    fun setQuantityDialogListener(listener: QuantityDialogListener) {
        this.listener = listener
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
