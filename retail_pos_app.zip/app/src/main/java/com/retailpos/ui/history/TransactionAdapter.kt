package com.retailpos.ui.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.retailpos.R
import com.retailpos.data.entity.Transaction
import com.retailpos.databinding.ItemTransactionBinding
import com.retailpos.utils.CurrencyFormatter
import com.retailpos.utils.DateTimeUtils

class TransactionAdapter(private val listener: TransactionClickListener) :
    ListAdapter<Transaction, TransactionAdapter.TransactionViewHolder>(TransactionDiffCallback()) {

    interface TransactionClickListener {
        fun onTransactionClick(transaction: Transaction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TransactionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TransactionViewHolder(private val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.btnViewDetails.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener.onTransactionClick(getItem(position))
                }
            }

            binding.root.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener.onTransactionClick(getItem(position))
                }
            }
        }

        fun bind(transaction: Transaction) {
            val context = binding.root.context

            // Format and display transaction details
            binding.tvTransactionId.text = context.getString(
                R.string.history_id,
                transaction.id.toString()
            )
            binding.tvDate.text = context.getString(
                R.string.history_date,
                DateTimeUtils.formatDate(transaction.date)
            )
            binding.tvTime.text = context.getString(
                R.string.history_time,
                DateTimeUtils.formatTime(transaction.date)
            )
            binding.tvItems.text = "Items: ${transaction.itemCount}"
            binding.tvTotal.text = CurrencyFormatter.formatToRupiah(transaction.totalAmount)
        }
    }

    class TransactionDiffCallback : DiffUtil.ItemCallback<Transaction>() {
        override fun areItemsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
            return oldItem == newItem
        }
    }
}
