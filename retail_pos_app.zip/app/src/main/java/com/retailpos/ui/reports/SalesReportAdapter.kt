package com.retailpos.ui.reports

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.retailpos.databinding.ItemSalesBinding
import com.retailpos.utils.CurrencyFormatter
import com.retailpos.utils.DateTimeUtils

class SalesReportAdapter : 
    ListAdapter<SalesReportViewModel.DailySalesSummary, SalesReportAdapter.SalesViewHolder>(SalesDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SalesViewHolder {
        val binding = ItemSalesBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return SalesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SalesViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class SalesViewHolder(private val binding: ItemSalesBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: SalesReportViewModel.DailySalesSummary) {
            binding.tvDate.text = DateTimeUtils.formatDate(item.date)
            binding.tvTransactionCount.text = "Transactions: ${item.transactionCount}"
            binding.tvTotalSales.text = CurrencyFormatter.formatToRupiah(item.totalSales)
        }
    }

    class SalesDiffCallback : DiffUtil.ItemCallback<SalesReportViewModel.DailySalesSummary>() {
        override fun areItemsTheSame(
            oldItem: SalesReportViewModel.DailySalesSummary,
            newItem: SalesReportViewModel.DailySalesSummary
        ): Boolean {
            return DateTimeUtils.formatDate(oldItem.date) == DateTimeUtils.formatDate(newItem.date)
        }

        override fun areContentsTheSame(
            oldItem: SalesReportViewModel.DailySalesSummary,
            newItem: SalesReportViewModel.DailySalesSummary
        ): Boolean {
            return oldItem == newItem
        }
    }
}
