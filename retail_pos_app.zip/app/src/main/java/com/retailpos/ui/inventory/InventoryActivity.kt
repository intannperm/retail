package com.retailpos.ui.inventory

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.retailpos.R
import com.retailpos.RetailPosApplication
import com.retailpos.data.entity.Product
import com.retailpos.databinding.ActivityInventoryBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class InventoryActivity : AppCompatActivity(), ProductAdapter.ProductClickListener {

    private lateinit var binding: ActivityInventoryBinding
    private lateinit var productAdapter: ProductAdapter

    private val viewModel: InventoryViewModel by viewModels {
        InventoryViewModelFactory((application as RetailPosApplication).productRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInventoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Inventory Management"

        setupRecyclerView()
        setupTabLayout()
        setupSearch()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        productAdapter = ProductAdapter(this)
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@InventoryActivity)
            adapter = productAdapter
            addItemDecoration(DividerItemDecoration(this@InventoryActivity, DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupTabLayout() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> { // All Products
                        viewModel.allProducts.observe(this@InventoryActivity) { products ->
                            productAdapter.submitList(products)
                            updateEmptyStateVisibility(products.isEmpty())
                        }
                    }
                    1 -> { // Low Stock
                        viewModel.lowStockProducts.observe(this@InventoryActivity) { products ->
                            productAdapter.submitList(products)
                            updateEmptyStateVisibility(products.isEmpty())
                        }
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.setSearchQuery(newText ?: "")
                return true
            }
        })

        viewModel.searchResults.observe(this) { products ->
            if (viewModel.searchQuery.value.isNotEmpty()) {
                productAdapter.submitList(products)
                updateEmptyStateVisibility(products.isEmpty())
            }
        }
    }

    private fun setupClickListeners() {
        binding.fabAddProduct.setOnClickListener {
            val intent = Intent(this, AddEditProductActivity::class.java)
            startActivity(intent)
        }
    }

    private fun observeViewModel() {
        // Default to show all products
        viewModel.allProducts.observe(this) { products ->
            if (viewModel.searchQuery.value.isEmpty() && binding.tabLayout.selectedTabPosition == 0) {
                productAdapter.submitList(products)
                updateEmptyStateVisibility(products.isEmpty())
            }
        }

        // Observe loading state
        lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }

        // Observe error messages
        lifecycleScope.launch {
            viewModel.errorMessage.collectLatest { errorMessage ->
                if (errorMessage != null) {
                    Toast.makeText(this@InventoryActivity, errorMessage, Toast.LENGTH_SHORT).show()
                    viewModel.resetErrorMessage()
                }
            }
        }
    }

    private fun updateEmptyStateVisibility(isEmpty: Boolean) {
        binding.tvEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    override fun onProductClick(product: Product) {
        val intent = Intent(this, AddEditProductActivity::class.java).apply {
            putExtra(AddEditProductActivity.EXTRA_PRODUCT_ID, product.id)
        }
        startActivity(intent)
    }

    override fun onDeleteClick(product: Product) {
        AlertDialog.Builder(this)
            .setTitle("Delete Product")
            .setMessage("Are you sure you want to delete ${product.name}?")
            .setPositiveButton("Delete") { _, _ ->
                viewModel.deleteProduct(product)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
