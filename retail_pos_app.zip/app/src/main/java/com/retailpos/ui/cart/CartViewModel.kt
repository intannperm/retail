package com.retailpos.ui.cart

import androidx.lifecycle.*
import com.retailpos.data.entity.Product
import com.retailpos.data.entity.Transaction
import com.retailpos.data.entity.TransactionItem
import com.retailpos.data.repository.ProductRepository
import com.retailpos.data.repository.TransactionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.*

class CartViewModel(
    private val productRepository: ProductRepository,
    private val transactionRepository: TransactionRepository
) : ViewModel() {

    // Search query for products
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    // List of searched products
    private var _searchResults = MutableLiveData<List<Product>>()
    val searchResults: LiveData<List<Product>> = _searchResults

    // Cart items
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems

    // Total amount
    private val _totalAmount = MutableStateFlow(0.0)
    val totalAmount: StateFlow<Double> = _totalAmount

    // Last completed transaction ID
    private val _lastTransactionId = MutableStateFlow<Long?>(null)
    val lastTransactionId: StateFlow<Long?> = _lastTransactionId

    // Loading state
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    // Error message
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    /**
     * Update search query and perform search
     */
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        search(query)
    }

    /**
     * Search products by name or code
     */
    private fun search(query: String) {
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }

        viewModelScope.launch {
            productRepository.searchProducts(query).collect { products ->
                _searchResults.value = products
            }
        }
    }

    /**
     * Get a product by code
     */
    fun getProductByCode(code: String): Flow<Product?> {
        return productRepository.getProductByCode(code)
    }

    /**
     * Add a product to the cart
     */
    fun addToCart(product: Product, quantity: Int = 1) {
        // Check if the product already exists in the cart
        val existingItem = _cartItems.value.find { it.product.id == product.id }

        if (existingItem != null) {
            // Update quantity if product already exists
            updateCartItemQuantity(existingItem, existingItem.quantity + quantity)
        } else {
            // Add new item if product doesn't exist in cart
            val newItem = CartItem(product, quantity, product.price * quantity)
            _cartItems.update { currentList -> currentList + newItem }
            recalculateTotal()
        }
    }

    /**
     * Update the quantity of a cart item
     */
    fun updateCartItemQuantity(item: CartItem, newQuantity: Int) {
        if (newQuantity <= 0) {
            removeFromCart(item)
            return
        }

        _cartItems.update { currentList ->
            currentList.map {
                if (it.product.id == item.product.id) {
                    it.copy(quantity = newQuantity, subtotal = it.product.price * newQuantity)
                } else {
                    it
                }
            }
        }
        recalculateTotal()
    }

    /**
     * Remove an item from the cart
     */
    fun removeFromCart(item: CartItem) {
        _cartItems.update { currentList ->
            currentList.filter { it.product.id != item.product.id }
        }
        recalculateTotal()
    }

    /**
     * Clear all items from the cart
     */
    fun clearCart() {
        _cartItems.value = emptyList()
        _totalAmount.value = 0.0
    }

    /**
     * Recalculate the total amount
     */
    private fun recalculateTotal() {
        _totalAmount.value = _cartItems.value.sumOf { it.subtotal }
    }

    /**
     * Complete the transaction and save to database
     */
    fun completeTransaction(cashierName: String = "Cashier", paymentMethod: String = "Cash") {
        if (_cartItems.value.isEmpty()) {
            _errorMessage.value = "Cart is empty"
            return
        }

        _isLoading.value = true

        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Create transaction
                val transaction = Transaction(
                    date = Date(),
                    totalAmount = _totalAmount.value,
                    itemCount = _cartItems.value.sumOf { it.quantity },
                    cashierName = cashierName,
                    paymentMethod = paymentMethod
                )

                // Create transaction items
                val transactionItems = _cartItems.value.map { cartItem ->
                    TransactionItem(
                        transactionId = 0, // Will be updated after transaction is saved
                        productId = cartItem.product.id,
                        productCode = cartItem.product.code,
                        productName = cartItem.product.name,
                        quantity = cartItem.quantity,
                        unitPrice = cartItem.product.price,
                        subtotal = cartItem.subtotal
                    )
                }

                // Save transaction to database
                val transactionId = transactionRepository.saveTransaction(transaction, transactionItems)
                _lastTransactionId.value = transactionId

                // Clear cart after successful transaction
                clearCart()
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Error completing transaction: ${e.message}"
                e.printStackTrace()
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Reset error message
     */
    fun resetErrorMessage() {
        _errorMessage.value = null
    }

    /**
     * Reset last transaction ID
     */
    fun resetLastTransactionId() {
        _lastTransactionId.value = null
    }

    /**
     * Data class representing an item in the cart
     */
    data class CartItem(
        val product: Product,
        val quantity: Int,
        val subtotal: Double
    )
}

/**
 * Factory for creating CartViewModel with dependencies
 */
class CartViewModelFactory(
    private val productRepository: ProductRepository,
    private val transactionRepository: TransactionRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CartViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CartViewModel(productRepository, transactionRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
