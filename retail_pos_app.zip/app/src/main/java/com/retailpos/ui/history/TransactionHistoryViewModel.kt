package com.retailpos.ui.history

import androidx.lifecycle.*
import com.retailpos.data.entity.Transaction
import com.retailpos.data.repository.TransactionRepository
import com.retailpos.utils.DateTimeUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*

class TransactionHistoryViewModel(private val repository: TransactionRepository) : ViewModel() {

    // Date range for filtering
    private val _startDate = MutableStateFlow(DateTimeUtils.getStartOfToday())
    val startDate: StateFlow<Date> = _startDate.asStateFlow()

    private val _endDate = MutableStateFlow(DateTimeUtils.getEndOfToday())
    val endDate: StateFlow<Date> = _endDate.asStateFlow()

    // Transactions within date range
    private val _transactions = MutableLiveData<List<Transaction>>()
    val transactions: LiveData<List<Transaction>> = _transactions

    // Total sales within date range
    private val _totalSales = MutableStateFlow(0.0)
    val totalSales: StateFlow<Double> = _totalSales.asStateFlow()

    // Loading state
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Current filter type
    private val _currentFilter = MutableStateFlow(FilterType.TODAY)
    val currentFilter: StateFlow<FilterType> = _currentFilter.asStateFlow()

    init {
        loadTransactions()
    }

    /**
     * Load transactions within current date range
     */
    private fun loadTransactions() {
        _isLoading.value = true
        viewModelScope.launch {
            repository.getTransactionsByDateRange(_startDate.value, _endDate.value)
                .collectLatest { transactions ->
                    _transactions.value = transactions
                    _isLoading.value = false
                }
        }

        viewModelScope.launch {
            repository.getTotalSalesByDateRange(_startDate.value, _endDate.value)
                .collectLatest { total ->
                    _totalSales.value = total ?: 0.0
                }
        }
    }

    /**
     * Set date range and reload transactions
     */
    fun setDateRange(startDate: Date, endDate: Date, filterType: FilterType) {
        _startDate.value = DateTimeUtils.getStartOfDay(startDate)
        _endDate.value = DateTimeUtils.getEndOfDay(endDate)
        _currentFilter.value = filterType
        loadTransactions()
    }

    /**
     * Set today's date range
     */
    fun setTodayFilter() {
        _startDate.value = DateTimeUtils.getStartOfToday()
        _endDate.value = DateTimeUtils.getEndOfToday()
        _currentFilter.value = FilterType.TODAY
        loadTransactions()
    }

    /**
     * Set this week's date range
     */
    fun setThisWeekFilter() {
        val calendar = Calendar.getInstance()
        
        // Set to start of week (assuming Sunday is first day of week)
        calendar.set(Calendar.DAY_OF_WEEK, calendar.firstDayOfWeek)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        _startDate.value = calendar.time
        
        // Set to end of week
        calendar.add(Calendar.DAY_OF_WEEK, 6)
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        _endDate.value = calendar.time
        
        _currentFilter.value = FilterType.THIS_WEEK
        loadTransactions()
    }

    /**
     * Set this month's date range
     */
    fun setThisMonthFilter() {
        val calendar = Calendar.getInstance()
        
        // Set to start of month
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        _startDate.value = calendar.time
        
        // Set to end of month
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        _endDate.value = calendar.time
        
        _currentFilter.value = FilterType.THIS_MONTH
        loadTransactions()
    }

    /**
     * Get transaction by ID
     */
    fun getTransactionById(id: Long): LiveData<Transaction> {
        return repository.getTransactionById(id).asLiveData()
    }

    /**
     * Filter types
     */
    enum class FilterType {
        TODAY, THIS_WEEK, THIS_MONTH, CUSTOM
    }
}

/**
 * Factory for creating TransactionHistoryViewModel with dependencies
 */
class TransactionHistoryViewModelFactory(private val repository: TransactionRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TransactionHistoryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TransactionHistoryViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
