package com.retailpos.ui.inventory

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.retailpos.R
import com.retailpos.RetailPosApplication
import com.retailpos.data.entity.Product
import com.retailpos.databinding.ActivityAddEditProductBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AddEditProductActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PRODUCT_ID = "extra_product_id"
    }

    private lateinit var binding: ActivityAddEditProductBinding
    private val viewModel: InventoryViewModel by viewModels {
        InventoryViewModelFactory((application as RetailPosApplication).productRepository)
    }

    private var productId: Long = 0
    private var isEditMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up action bar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Check if we're editing an existing product
        productId = intent.getLongExtra(EXTRA_PRODUCT_ID, 0)
        isEditMode = productId > 0

        // Set activity title based on mode
        supportActionBar?.title = if (isEditMode) {
            getString(R.string.product_edit)
        } else {
            getString(R.string.product_add)
        }

        // If editing, load product data
        if (isEditMode) {
            loadProductData()
        }

        setupClickListeners()
        observeViewModel()
    }

    private fun loadProductData() {
        viewModel.getProduct(productId).observe(this) { product ->
            product?.let {
                binding.etProductCode.setText(it.code)
                binding.etProductName.setText(it.name)
                binding.etPrice.setText(it.price.toString())
                binding.etStock.setText(it.stock.toString())
                binding.etCategory.setText(it.category)
                binding.etDescription.setText(it.description)
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnSave.setOnClickListener {
            saveProduct()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }

        lifecycleScope.launch {
            viewModel.errorMessage.collectLatest { errorMessage ->
                if (errorMessage != null) {
                    Toast.makeText(this@AddEditProductActivity, errorMessage, Toast.LENGTH_SHORT).show()
                    viewModel.resetErrorMessage()
                }
            }
        }
    }

    private fun saveProduct() {
        val code = binding.etProductCode.text.toString().trim()
        val name = binding.etProductName.text.toString().trim()
        val priceStr = binding.etPrice.text.toString().trim()
        val stockStr = binding.etStock.text.toString().trim()
        val category = binding.etCategory.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()

        // Validate inputs
        if (code.isEmpty() || name.isEmpty() || priceStr.isEmpty() || stockStr.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Parse price and stock
        val price = try {
            priceStr.toDouble()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Invalid price format", Toast.LENGTH_SHORT).show()
            return
        }

        val stock = try {
            stockStr.toInt()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Invalid stock format", Toast.LENGTH_SHORT).show()
            return
        }

        // Create product object
        val product = Product(
            id = if (isEditMode) productId else 0,
            code = code,
            name = name,
            price = price,
            stock = stock,
            category = category,
            description = description
        )

        // Save product
        if (isEditMode) {
            viewModel.updateProduct(product)
        } else {
            viewModel.insertProduct(product)
        }

        // Show success message and finish activity
        Toast.makeText(
            this,
            getString(R.string.success_saved),
            Toast.LENGTH_SHORT
        ).show()
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            // Show confirmation dialog if fields have been filled
            if (hasUserMadeChanges()) {
                AlertDialog.Builder(this)
                    .setTitle("Discard Changes")
                    .setMessage("Are you sure you want to discard your changes?")
                    .setPositiveButton("Discard") { _, _ -> finish() }
                    .setNegativeButton("Cancel", null)
                    .show()
            } else {
                finish()
            }
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun hasUserMadeChanges(): Boolean {
        // Check if any fields have been filled out
        return binding.etProductCode.text.toString().isNotEmpty() ||
                binding.etProductName.text.toString().isNotEmpty() ||
                binding.etPrice.text.toString().isNotEmpty() ||
                binding.etStock.text.toString().isNotEmpty() ||
                binding.etCategory.text.toString().isNotEmpty() ||
                binding.etDescription.text.toString().isNotEmpty()
    }

    override fun onBackPressed() {
        if (hasUserMadeChanges()) {
            AlertDialog.Builder(this)
                .setTitle("Discard Changes")
                .setMessage("Are you sure you want to discard your changes?")
                .setPositiveButton("Discard") { _, _ -> super.onBackPressed() }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            super.onBackPressed()
        }
    }
}
