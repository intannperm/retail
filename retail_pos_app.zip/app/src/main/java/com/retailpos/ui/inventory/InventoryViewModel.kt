package com.retailpos.ui.inventory

import androidx.lifecycle.*
import com.retailpos.data.entity.Product
import com.retailpos.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class InventoryViewModel(private val repository: ProductRepository) : ViewModel() {

    // All products from repository
    val allProducts = repository.allProducts.asLiveData()
    
    // Low stock products
    val lowStockProducts = repository.lowStockProducts.asLiveData()
    
    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    // Search results
    private val _searchResults = MutableLiveData<List<Product>>()
    val searchResults: LiveData<List<Product>> = _searchResults
    
    // Loading state
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    // Error message
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    /**
     * Update search query and perform search
     */
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        search(query)
    }

    /**
     * Search products by name or code
     */
    private fun search(query: String) {
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }

        viewModelScope.launch {
            repository.searchProducts(query).collect { products ->
                _searchResults.value = products
            }
        }
    }

    /**
     * Get a product by ID
     */
    fun getProduct(id: Long): LiveData<Product> {
        return repository.getProductById(id).asLiveData()
    }

    /**
     * Insert a new product
     */
    fun insertProduct(product: Product) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                repository.insert(product)
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Error inserting product: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Update an existing product
     */
    fun updateProduct(product: Product) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                repository.update(product)
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Error updating product: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Delete a product
     */
    fun deleteProduct(product: Product) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                repository.delete(product)
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Error deleting product: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Reset error message
     */
    fun resetErrorMessage() {
        _errorMessage.value = null
    }
}

/**
 * Factory for creating InventoryViewModel with dependencies
 */
class InventoryViewModelFactory(private val repository: ProductRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InventoryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return InventoryViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
