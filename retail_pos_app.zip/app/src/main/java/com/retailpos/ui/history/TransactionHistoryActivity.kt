package com.retailpos.ui.history

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.retailpos.R
import com.retailpos.RetailPosApplication
import com.retailpos.data.entity.Transaction
import com.retailpos.databinding.ActivityTransactionHistoryBinding
import com.retailpos.ui.receipt.ReceiptActivity
import com.retailpos.utils.CurrencyFormatter
import com.retailpos.utils.DateTimeUtils
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*

class TransactionHistoryActivity : AppCompatActivity(), TransactionAdapter.TransactionClickListener {

    private lateinit var binding: ActivityTransactionHistoryBinding
    private lateinit var adapter: TransactionAdapter

    private val viewModel: TransactionHistoryViewModel by viewModels {
        TransactionHistoryViewModelFactory((application as RetailPosApplication).transactionRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransactionHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.history_title)

        setupRecyclerView()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = TransactionAdapter(this)
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@TransactionHistoryActivity)
            adapter = this@TransactionHistoryActivity.adapter
        }
    }

    private fun setupClickListeners() {
        // Date filter buttons
        binding.btnToday.setOnClickListener {
            viewModel.setTodayFilter()
        }

        binding.btnWeek.setOnClickListener {
            viewModel.setThisWeekFilter()
        }

        binding.btnMonth.setOnClickListener {
            viewModel.setThisMonthFilter()
        }

        binding.btnCustomDate.setOnClickListener {
            showDateRangeDialog()
        }
    }

    private fun observeViewModel() {
        // Observe transactions
        viewModel.transactions.observe(this) { transactions ->
            adapter.submitList(transactions)
            updateEmptyStateVisibility(transactions.isEmpty())
        }

        // Observe total sales
        lifecycleScope.launch {
            viewModel.totalSales.collectLatest { totalSales ->
                binding.tvTotalSales.text = getString(
                    R.string.report_total_sales,
                    CurrencyFormatter.formatToRupiah(totalSales)
                )
            }
        }

        // Observe date range
        lifecycleScope.launch {
            viewModel.startDate.collectLatest { startDate ->
                updateDateFilterUI()
            }
        }

        lifecycleScope.launch {
            viewModel.endDate.collectLatest { endDate ->
                updateDateFilterUI()
            }
        }

        // Observe loading state
        lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }

        // Observe filter type
        lifecycleScope.launch {
            viewModel.currentFilter.collectLatest { filterType ->
                updateFilterButtonsUI(filterType)
            }
        }
    }

    private fun updateDateFilterUI() {
        val startDateStr = DateTimeUtils.formatDate(viewModel.startDate.value)
        val endDateStr = DateTimeUtils.formatDate(viewModel.endDate.value)

        supportActionBar?.subtitle = "Transactions: $startDateStr to $endDateStr"
    }

    private fun updateFilterButtonsUI(filterType: TransactionHistoryViewModel.FilterType) {
        // Reset all buttons to default style
        binding.btnToday.setBackgroundResource(android.R.color.transparent)
        binding.btnWeek.setBackgroundResource(android.R.color.transparent)
        binding.btnMonth.setBackgroundResource(android.R.color.transparent)

        // Highlight selected button
        when (filterType) {
            TransactionHistoryViewModel.FilterType.TODAY -> {
                binding.btnToday.setBackgroundResource(R.color.primary_light)
            }
            TransactionHistoryViewModel.FilterType.THIS_WEEK -> {
                binding.btnWeek.setBackgroundResource(R.color.primary_light)
            }
            TransactionHistoryViewModel.FilterType.THIS_MONTH -> {
                binding.btnMonth.setBackgroundResource(R.color.primary_light)
            }
            TransactionHistoryViewModel.FilterType.CUSTOM -> {
                // No button to highlight for custom
            }
        }
    }

    private fun updateEmptyStateVisibility(isEmpty: Boolean) {
        binding.tvEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun showDateRangeDialog() {
        val startCalendar = Calendar.getInstance().apply {
            time = viewModel.startDate.value
        }
        
        // First show start date picker
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                startCalendar.set(year, month, dayOfMonth)
                
                // After selecting start date, show end date picker
                val endCalendar = Calendar.getInstance().apply {
                    time = viewModel.endDate.value
                    // Make sure end date is not before start date
                    if (time.before(startCalendar.time)) {
                        time = startCalendar.time
                    }
                }
                
                DatePickerDialog(
                    this,
                    { _, endYear, endMonth, endDayOfMonth ->
                        endCalendar.set(endYear, endMonth, endDayOfMonth)
                        
                        // Ensure end date is not before start date
                        if (endCalendar.before(startCalendar)) {
                            Toast.makeText(this, "End date cannot be before start date", Toast.LENGTH_SHORT).show()
                            return@DatePickerDialog
                        }
                        
                        // Set the date range
                        viewModel.setDateRange(
                            startCalendar.time,
                            endCalendar.time,
                            TransactionHistoryViewModel.FilterType.CUSTOM
                        )
                    },
                    endCalendar.get(Calendar.YEAR),
                    endCalendar.get(Calendar.MONTH),
                    endCalendar.get(Calendar.DAY_OF_MONTH)
                ).show()
            },
            startCalendar.get(Calendar.YEAR),
            startCalendar.get(Calendar.MONTH),
            startCalendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    override fun onTransactionClick(transaction: Transaction) {
        val intent = Intent(this, ReceiptActivity::class.java).apply {
            putExtra(ReceiptActivity.EXTRA_TRANSACTION_ID, transaction.id)
        }
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
