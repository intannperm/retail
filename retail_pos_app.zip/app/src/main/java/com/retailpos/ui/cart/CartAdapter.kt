package com.retailpos.ui.cart

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.retailpos.databinding.ItemCartBinding
import com.retailpos.ui.cart.CartViewModel.CartItem
import com.retailpos.utils.CurrencyFormatter

class CartAdapter(private val listener: CartItemListener) : ListAdapter<CartItem, CartAdapter.CartItemViewHolder>(CartItemDiffCallback()) {

    interface CartItemListener {
        fun onCartItemQuantityChanged(item: CartItem, quantity: Int)
        fun onCartItemRemoved(item: CartItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartItemViewHolder {
        val binding = ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartItemViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartItemViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CartItemViewHolder(private val binding: ItemCartBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: CartItem) {
            // Set product information
            binding.tvProductName.text = item.product.name
            binding.tvProductCode.text = item.product.code
            binding.tvPrice.text = CurrencyFormatter.formatToRupiah(item.product.price)
            binding.tvSubtotal.text = CurrencyFormatter.formatToRupiah(item.subtotal)
            binding.etQuantity.setText(item.quantity.toString())

            // Quantity controls
            binding.btnDecrease.setOnClickListener {
                val newQuantity = (binding.etQuantity.text.toString().toIntOrNull() ?: 1) - 1
                if (newQuantity > 0) {
                    binding.etQuantity.setText(newQuantity.toString())
                    listener.onCartItemQuantityChanged(item, newQuantity)
                } else {
                    listener.onCartItemRemoved(item)
                }
            }

            binding.btnIncrease.setOnClickListener {
                val newQuantity = (binding.etQuantity.text.toString().toIntOrNull() ?: 1) + 1
                if (newQuantity <= item.product.stock) {
                    binding.etQuantity.setText(newQuantity.toString())
                    listener.onCartItemQuantityChanged(item, newQuantity)
                }
            }

            binding.btnRemove.setOnClickListener {
                listener.onCartItemRemoved(item)
            }

            // Handle manual quantity input
            binding.etQuantity.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val newQuantity = binding.etQuantity.text.toString().toIntOrNull() ?: 1
                    if (newQuantity > 0 && newQuantity <= item.product.stock) {
                        listener.onCartItemQuantityChanged(item, newQuantity)
                    } else if (newQuantity <= 0) {
                        listener.onCartItemRemoved(item)
                    } else {
                        // Reset to current quantity if out of stock
                        binding.etQuantity.setText(item.quantity.toString())
                    }
                }
            }
        }
    }

    private class CartItemDiffCallback : DiffUtil.ItemCallback<CartItem>() {
        override fun areItemsTheSame(oldItem: CartItem, newItem: CartItem): Boolean {
            return oldItem.product.id == newItem.product.id
        }

        override fun areContentsTheSame(oldItem: CartItem, newItem: CartItem): Boolean {
            return oldItem == newItem
        }
    }
}
